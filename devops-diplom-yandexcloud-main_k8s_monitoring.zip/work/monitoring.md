[Главная](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/task.md)

# Мониторинг (Prometheus + Grafana)

Мониторинг разворачивается Helm-чартом **kube-prometheus-stack**.
Доступ к Grafana организован через ingress-nginx по адресу:

- `http://<PUBLIC_IP>/grafana`

> В Terraform security group должен быть открыт TCP 80 (и опционально 443).

## 1) Установка ingress-nginx (80 порт)

Ingress разворачивается как **DaemonSet** с `hostNetwork: true` и `hostPort: 80`, чтобы было доступно по `http://<PUBLIC_IP>` без LoadBalancer.

```bash
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update

kubectl create ns ingress-nginx --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install ingress-nginx ingress-nginx/ingress-nginx \
  -n ingress-nginx \
  -f k8s/ingress-nginx/values-hostnetwork.yaml
```

Проверка:
```bash
kubectl -n ingress-nginx get pods -o wide
```

## 2) Установка kube-prometheus-stack

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

kubectl create ns monitoring --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
  -n monitoring \
  -f k8s/monitoring/values.yaml
```

## 3) Публикация Grafana через Ingress

```bash
kubectl apply -f k8s/monitoring/grafana-ingress.yaml
```

Проверка:
- открой `http://<PUBLIC_IP>/grafana`
- логин/пароль по умолчанию: `admin / admin` (задано в `k8s/monitoring/values.yaml`)
