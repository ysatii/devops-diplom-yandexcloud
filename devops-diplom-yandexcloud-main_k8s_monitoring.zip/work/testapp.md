[Главная](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/task.md)

# Тестовое приложение

Тестовое приложение собрано в Docker-образ и опубликовано в registry.

Деплой приложения в кластер вынесен в папку: `k8s/testapp/`.

## Деплой в Kubernetes

1) Укажи образ приложения в `k8s/testapp/10-deployment.yaml` (поле `image:`).

2) Примени манифесты:

```bash
kubectl apply -f k8s/testapp/
```

3) Проверка:
- открой в браузере `http://<PUBLIC_IP>/` (публичный IP любой ноды, где запущен ingress-nginx)