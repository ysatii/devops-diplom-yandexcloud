# Дипломный практикум в Yandex.Cloud - Мельник Юрий Алексадрович

# Этапы выполнения задания
[Задание](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/task.md)  
[Создание облачной инфраструктуры](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/cloud.md)  
[Создание Kubernetes кластера](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/kubernetes.md)  
[Создание тестового приложения](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/testapp.md)  
[Подготовка cистемы мониторинга и деплой приложения](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/monitoring.md)  
[Установка и настройка CI/CD](https://github.com/ysatii/devops-diplom-yandexcloud/blob/main/ci-cd.md)  

## Kubernetes манифесты

Манифесты/values для деплоя тестового приложения и мониторинга лежат в папке `k8s/`.

