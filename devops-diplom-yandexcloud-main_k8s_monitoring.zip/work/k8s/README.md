# Kubernetes manifests (test app + monitoring)

Цель: поднять ingress-nginx (80 порт), задеплоить тестовое приложение и поставить мониторинг (Prometheus + Grafana).

## Требования
- кластер Kubernetes поднят (Kubespray)
- `kubectl` настроен на кластер
- Helm v3 установлен на машине с `kubectl`

## 1) Ingress controller (ingress-nginx) на 80 порту
```bash
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update

kubectl create ns ingress-nginx --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install ingress-nginx ingress-nginx/ingress-nginx \
  -n ingress-nginx \
  -f k8s/ingress-nginx/values-hostnetwork.yaml
```

Проверка:
```bash
kubectl -n ingress-nginx get pods -o wide
```

## 2) Тестовое приложение
1) Укажи образ приложения в `k8s/testapp/deployment.yaml` (поле `image:`).
2) Применяй манифесты:

```bash
kubectl apply -f k8s/testapp/
```

Проверка: открой **http://<PUBLIC_IP>/** (любой ноды, где поднялся ingress-nginx).

## 3) Мониторинг (kube-prometheus-stack) + Grafana через Ingress
```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

kubectl create ns monitoring --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
  -n monitoring \
  -f k8s/monitoring/values.yaml

kubectl apply -f k8s/monitoring/grafana-ingress.yaml
```

Проверка: **http://<PUBLIC_IP>/grafana**

Логин/пароль (по умолчанию в values): `admin / admin`
